"""Mindshard Reference Library package."""
